// Copyright 2020 Troy Wang
// boost test for MModel

#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE Main
#include <boost/test/included/unit_test.hpp>

#include "header/MModel.h"

BOOST_AUTO_TEST_CASE(constructor) {
  // tests an expected input into the constructor. no error should be thrown
  BOOST_REQUIRE_NO_THROW(MModel cTest("gagggagaggcgagaaa", 0));

  // tests an expected input into the constructor. no error should be thrown
  BOOST_REQUIRE_NO_THROW(MModel cTest("gagggagaggcgagaaa", 3));

  // tests an expected input into the constructor. no error should be thrown
  BOOST_REQUIRE_NO_THROW(MModel cTest("gagggagaggcgagaaa", 5));

  // tests an expected input into the constructor. no error should be thrown
  BOOST_REQUIRE_NO_THROW(MModel cTest("gagggagaggcgagaaa", 7));
}

BOOST_AUTO_TEST_CASE(Korder) {
  // creating MModel to run freq on with kgram 0
  MModel cTest("gagggagaggcgagaaa", 0);

  // ensure kOrder() is returning correct value
  BOOST_REQUIRE(cTest.kOrder() == 0);

  // creating MModel to run freq on with kgram 3
  MModel cTest2("gagggagaggcgagaaa", 3);

  // ensure kOrder() is returning correct value
  BOOST_REQUIRE(cTest2.kOrder() == 3);
}

BOOST_AUTO_TEST_CASE(freq) {
  // creating MModel to run freq on with kgram 0
  MModel cTest("gagggagaggcgagaaa", 0);

  // test calling freq on cTest with a correct kgram
  BOOST_REQUIRE_NO_THROW(cTest.freq(""));

  // test calling freq on cTest with an incorrect kgram
  BOOST_REQUIRE_THROW(cTest.freq("a"), std::runtime_error);

  // double check value returned by freq
  BOOST_REQUIRE(cTest.freq("") == 17);

  // test calling freq on cTest with a correct kgram
  BOOST_REQUIRE_NO_THROW(cTest.freq("", 'a'));

  // test calling freq on cTest with an incorrect kgram
  BOOST_REQUIRE_THROW(cTest.freq("a", 'a'), std::runtime_error);

  // double check value returned by freq
  BOOST_REQUIRE(cTest.freq("", 'a') == 7);

  // double check value returned by freq
  BOOST_REQUIRE(cTest.freq("", 'c') == 1);

  // double check value returned by freq
  BOOST_REQUIRE(cTest.freq("", 'g') == 9);

  // double check value returned by freq when char not in input
  BOOST_REQUIRE(cTest.freq("", 'z') == 0);

  // creating MModel to run freq on with kgram 3
  MModel cTest2("gagggagaggcgagaaa", 3);

  // test calling freq on cTest with an incorrect kgram
  BOOST_REQUIRE_THROW(cTest2.freq("a"), std::runtime_error);

  // double check value returned by freq
  BOOST_REQUIRE(cTest2.freq("aaa") == 1);

  // double check value returned by freq
  BOOST_REQUIRE(cTest2.freq("gag") == 4);

  // test calling freq on cTest2 with an incorrect kgram
  BOOST_REQUIRE_THROW(cTest2.freq("a", 'a'), std::runtime_error);

  // test calling freq on cTest2 with a correct kgram
  BOOST_REQUIRE_NO_THROW(cTest2.freq("aaa", 'a'));

  // double check value returned by freq when next char not in input
  BOOST_REQUIRE(cTest2.freq("aaa", 'a') == 0);

  // double check value returned by freq
  BOOST_REQUIRE(cTest2.freq("gcg", 'a') == 1);
}

BOOST_AUTO_TEST_CASE(kRand) {
  // creating MModel to run freq on with kgram 0
  MModel cTest("gagggagaggcgagaaa", 0);

  // test calling kRand on cTest with an incorrect kgram
  BOOST_REQUIRE_THROW(cTest.kRand("a"), std::runtime_error);

  // test calling kRand on cTest with a correct kgram
  BOOST_REQUIRE_NO_THROW(cTest.kRand(""));

  // creating MModel to run freq on with kgram 3
  MModel cTest2("gagggagaggcgagaaa", 3);

  // test calling kRand on cTest2 with an incorrect kgram
  BOOST_REQUIRE_THROW(cTest2.kRand("a"), std::runtime_error);

  // test calling kRand on cTest2 with an correct kgram not in input
  BOOST_REQUIRE_THROW(cTest2.kRand("ccc"), std::runtime_error);

  // test calling kRand on cTest2 with a correct kgram
  BOOST_REQUIRE_NO_THROW(cTest2.kRand("aaa"));
}

BOOST_AUTO_TEST_CASE(generate) {
  // creating MModel to run freq on with kgram 0
  MModel cTest("gagggagaggcgagaaa", 0);

  // test calling generate on cTest with an incorrect kgram
  BOOST_REQUIRE_THROW(cTest.generate("a", 5), std::runtime_error);

  // test calling generate on cTest with a correct kgram
  BOOST_REQUIRE_NO_THROW(cTest.generate("", 5));

  // test calling generate on cTest with a correct kgram and
  // checking length of return
  BOOST_REQUIRE(cTest.generate("", 5).length() == 5);

  // test calling generate on cTest with a correct kgram and
  // checking length of return
  BOOST_REQUIRE(cTest.generate("", 7).length() == 7);

  // creating MModel to run freq on with kgram 3
  MModel cTest2("gagggagaggcgagaaa", 3);

  // test calling generate on cTest2 with an incorrect kgram
  BOOST_REQUIRE_THROW(cTest2.generate("a", 5), std::runtime_error);

  // test calling generate on cTest with a correct kgram
  BOOST_REQUIRE_NO_THROW(cTest2.generate("ggg", 5));

  // test calling generate on cTest with a correct kgram and
  // checking length of return
  BOOST_REQUIRE(cTest2.generate("aag", 5).length() == 5);

  // test calling generate on cTest with a correct kgram and
  // checking length of return
  BOOST_REQUIRE(cTest2.generate("gcg", 7).length() == 7);
}

BOOST_AUTO_TEST_CASE(overloaded_function) {
  // creating MModel to run freq on with kgram 0
  MModel cTest("gagggagaggcgagaaa", 1);

  // redirects the constructors overloaded << to the boost test stream.
  boost::test_tools::output_test_stream output;

  output << cTest;

  // test output is equal to expected input
  BOOST_REQUIRE(output.is_equal("Original text: gagggagaggcgagaaa"
  "\nOrder: 1"
  "\nAlphabet: gac\n"
  "Markov Map: \n"
  "Kgram: a Frequency: 7\n"
  "Kgram+1: aa Frequency: 2\n"
  "Kgram+1: ag Frequency: 5\n"
  "Kgram: c Frequency: 1\n"
  "Kgram+1: cg Frequency: 1\n"
  "Kgram: g Frequency: 9\n"
  "Kgram+1: ga Frequency: 5\n"
  "Kgram+1: gc Frequency: 1\n"
  "Kgram+1: gg Frequency: 3\n"
));
}
