/**********************************************************************
 *  readme.txt template                                                   
 *  Markov Model
 **********************************************************************/

Name: Troy Wang

Hours to complete assignment: 5 hours
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
So I was able to make a functioning markov model of a given string. Based on what the string is given with a kgram 
size of k, it can predict the next character that will come after the kgram. If the kgram size is 0, then it will pseudo
-randomly spit out characters in the alphabet (characters that have appeared in the string). I say pseudorandomly because
it is still weighted by the frequency of each letter, similar to how it predicts what will come after an existing kgram.


  /**********************************************************************
 *  Discuss one or more key algorithms, data structures, or 
 *  OO designs that were central to the assignment.
 **********************************************************************/
I used a map to hold the kgrams and their frequencies. This let me look up the kgrams and see how many times they appeared
in the given string. Additionally, I also added their existing kgram+1's and their frequencies so that I could use them to
predict which character should come next. I took advantage of the fact that maps given an unknown key will give zero as
the key value, which allowed me to bypass inserting all possible kgrams and just focus on only the kgrams in the string,
saving some space (this would be more apparent if we had many combinations, such as an extremely long kgram).

/**********************************************************************
 *  Briefly explain the workings of the features you implemented.
 *  Include code excerpts.
 **********************************************************************/
In the MModel, I first made the capability to give the frequency of each kgram and their kgram+1's.
To do this, I simply got the value from the map that I had created in the constructor (with some addition base exceptions,
such as if the kgram length was 0).

freq method code minus the exception checking
-----------------------------------------------------
if (order == 0) {
    return inputText.length();
}

return kGramMap[kgram];

------------------------------------------------------

Next, I used those frequencies to predict which character is coming next. To do so, I created a string consisting of 
the +1 characters, adding one instance of the character for each time it occurred. Then I pseudo-randomly created a
random number to pick a character in that string.

kRand method code minus the exception checking
-------------------------------------------------------
// simulate frequency of next letter by adding more of them to string
  std::string nextFrequency;
  for (unsigned int i = 0; i < alphabet.length(); i++) {
    for (int j = 0; j < kGramMap[kgram + alphabet[i]]; j++) {
      nextFrequency += alphabet[i];
    }
  }

//return random char in nextFrequency
return nextFrequency[rand() % nextFrequency.size()];

-------------------------------------------------------

Finally, I extrapolated the kRand function to be called repeatedly to generate up to a given desired length. To do this,
I simply took the kgram and called kRand, adding it to my return string. Then I shifted the kgram to include the most
recent character and discarded the left most character. This way, I am always using the kgram consisting of the right
most characters. 

generate code minus the exception testing
-------------------------------------------------------

for (int i = order; i < L ; i++) {
    // generate next char
    char tempC = kRand(tempKGram);
    // add next char to return string
    generatedString += tempC;
    
    // add next char to temkKGram
    tempKGram += tempC;
    // delete first char in tempKGram
    tempKGram.erase(0,1);

  }

return generatedString;

-------------------------------------------------------

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/
I did complete the whole assignment. I know that it does because the output is exactly what I expect in terms of
length and what characters show up. 
The randomness makes some difficulty, but if I run it multiple times, it doesn't give the same result where the 
functions are supposed to be random, so I know there is some variation that is occurring. 



/**********************************************************************
 *  Does your implementation pass the unit tests?
 *  Indicate yes or no, and explain how you know that it does or does not.
 **********************************************************************/
My implementation did pass the unit tests. I know that it does not throw exceptions unless a given parameter is 
incorrect, thanks to the boost testing and my own personal testing. Additionally, the outputs all match with what I 
expect in terms of values (for the non random functions) and length and characters appearing (for the random functions).



 /**********************************************************************
 *  Describe where you used exceptions. 
 *  Provide files and lines of the code.
 ***********************************************************************/
I used exceptions to check if the kgram size was matching the order and also if the kgram did not appear in the given
input string.

All the exceptions that I used were in MModel.cpp
Line numbers are: 56, 70, 83, 86, and 104




 /**********************************************************************
 *  Describe where you used lambda expression if any
 *  Provide files and lines of the code.
 ***********************************************************************/
I did use a lambda expression. I used it in my constructor for MModel. I noticed that I was using the same code to add
the kgrams and kgrams+1 to my map, so I turned that code into a temporary function using a lambda expression so that I
could just call the temporary function repeatedly.

The lambda expression is in lines 21-27 in MModel.cpp


/**********************************************************************
 *  List whatever help (if any) you received from lab TAs,
 *  classmates, or anyone else.
 **********************************************************************/
N/A


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/

N/A

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
I moved the header file into its own directory to avoid an include error from cpplint. I did modify the include 
directive to account for that, so it should run just fine, but I just wanted to let you know in case you were wondering
why there was a folder named "header" instead of my MModel.h file. The MModel.h file is in that folder.