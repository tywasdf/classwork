// Copyright 2020 Troy Wang
#include <ctime>
#include <cstdlib>
#include "header/MModel.h"


MModel::MModel(std::string text, int k) {
  srand(time(NULL));
  order = k;
  inputText = text;
  int textLength = (unsigned) inputText.length();

  // generate alphabet
  for (int i = 0; i < textLength; i++) {
    if (alphabet.find(inputText[i]) == std::string::npos) {
      alphabet += inputText[i];
    }
  }

  // create lambda expression to add key to kgram map
  auto addToKGramMap = [this](std::string key) {
    if (kGramMap.find(key) == kGramMap.end()) {
      kGramMap[key] = 1;
    } else {
      kGramMap[key] += 1;
    }
  };

  // generate map
  for (int i = 0; i < textLength; i++) {
    std::string temp;

    // make kgram
    for (int j = i; j < i + k; j++) {
      temp += inputText[j % textLength];
    }

    // add kgram to kGramMap
    addToKGramMap(temp);

    // generate k+1
    temp += inputText[(i + k) % textLength];

    // add kgram+1 to kGramMap
    addToKGramMap(temp);
  }
}

// return order
int MModel::kOrder() {
  return order;
}

// return frequency of kgram
int MModel::freq(std::string kgram) {
  if (kgram.length() != (unsigned) order) {
    throw std::runtime_error("kgram is not size k");
  }

  if (order == 0) {
    return inputText.length();
  }

  return kGramMap[kgram];
}

// return frequency of c after kgram
int MModel::freq(std::string kgram, char c) {
  if (kgram.length() != (unsigned) order) {
    throw std::runtime_error("kgram is not size k");
  }
  if (order == 0) {
    std::string s;
    s+=c;
    return kGramMap[s];
  }
  return kGramMap[kgram + c];
}

// return char that could come after kgram
char MModel::kRand(std:: string kgram) {
  if (kgram.length() != (unsigned) order) {
    throw std::runtime_error("kgram is not size k");
  }
  if (kGramMap[kgram] == 0) {
    throw std::runtime_error("kgram is not an existing kgram");
  }

  // simulate frequency of next letter by adding more of them to string
  std::string nextFrequency;
  for (unsigned int i = 0; i < alphabet.length(); i++) {
    for (int j = 0; j < kGramMap[kgram + alphabet[i]]; j++) {
      nextFrequency += alphabet[i];
    }
  }

  // return random char in nextFrequency
  return nextFrequency[rand() % nextFrequency.size()];
}

// generate a string of length L following Markov chain
std::string MModel::generate(std::string kgram, int L) {
  if (kgram.length() != (unsigned) order) {
    throw std::runtime_error("kgram is not size k");
  }

  std::string generatedString = kgram;
  std::string tempKGram = kgram;
  for (int i = order; i < L ; i++) {
    // generate next char
    char tempC = kRand(tempKGram);
    // add next char to return string
    generatedString += tempC;

    // add next char to temkKGram
    tempKGram += tempC;
    // delete first char in tempKGram
    tempKGram.erase(0, 1);
  }
  return generatedString;
}

// print model
std::ostream& operator<< (std::ostream& os, MModel model) {
  os << "Original text: " << model.inputText;
  os << "\nOrder: " << model.order << "\nAlphabet: " << model.alphabet;
  os << "\nMarkov Map: \n";
  unsigned int kOrder = (unsigned) model.kOrder();
  for (auto const &it : model.kGramMap) {
    if (it.first.length() == kOrder) {
      os << "Kgram: " << it.first << " Frequency: " << it.second << "\n";
    } else {
      os << "Kgram+1: " << it.first << " Frequency: " << it.second << "\n";
    }
  }
  return os;
}
