#ifndef MMODEL_H
#define MMODEL_H

#include <string>
#include <iostream>
#include <map>

class MModel{
  public:
    MModel (std::string text, int k);
    int kOrder();
    int freq(std::string kgram);
    int freq(std::string kgram, char c);
    char kRand(std:: string kgram);
    std::string generate(std::string kgram, int L);
    friend std::ostream& operator<< (std::ostream& os, MModel model);
  private:
    std::map<std::string, int> kGramMap;
    std::string inputText;
    std::string alphabet;
    int order;
    
};

#endif // MMODEL_H