// Copyright 2020 Troy Wang

#include "header/MModel.h"

int main(int argc, char** argv) {
  // Check for number of args
  if (argc != 3) {
    std::cout << "There is an incorrect number of args. "
                 "There should be 3 args.\n";
    return -1;
  }

  // convert args to ints
  int k = atoi(argv[1]);
  int l = atoi(argv[2]);

  std::string input;
  std::string current;

  // take in entirety of string
  while (std::cin >> current) {
    input += current;
    current = "";
  }

  // make MModel
  MModel model(input, k);

  // create Kgram of length K from first K chars
  current = input.substr(0, k);

  // print generated string of length l starting with kgram
  std::cout << model.generate(current, l) << "\n";
}
