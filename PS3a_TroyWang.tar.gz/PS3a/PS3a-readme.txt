/**********************************************************************
 *  readme.txt template                                                   
 *  Synthesizing a Plucked String Sound:
 *  CircularBuffer implementation with unit tests and exceptions 
 **********************************************************************/

Name: Troy Wang


Hours to complete assignment: 2 hours

/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
I created a ring buffer using a vector.
The ring buffer class successfully enqueues and dequeues items up to the capacity
that is entered when creating the CircularBuffer object.

I also used Boost testing to make sure that the ring buffer worked as intended,
testing every function and the constructor in several edge cases.




/**********************************************************************
 *  Discuss one or more key algorithms, data structures, or 
 *  OO designs that were central to the assignment.
 **********************************************************************/

To make the ring buffer, I used the vector. I essentially just accessed the vector
very similarly to how I would the array, but once the index went above the capacity-1,
I simply just set the index back down to 0 instead. 

I kept track of two indexes: the head and the tail. I also kept track of the size and the capacity
so I didn't have to constantly check the size of the vector.

I also never actually deleted the old data. Instead I just incremented the index for the head, so that
when the tail gets back to it, it will overwrite it with the element that got pushed.
I figured this wouldn't be an issue since we weren't accessing the buffer itself by user-input indexes and
since the vector was already set to a specific size (via resize).


/**********************************************************************
 *  Briefly explain the workings of the features you implemented.
 *  Include code excerpts.
 **********************************************************************/
As mentioned earlier, I was using vectors to make the ring buffer. 
The vector itself is stored as a private member of the CircularBuffer class
via this code in the header file:

std::vector<int16_t> buffer;

To manipulate the indexes to make it act like a ring buffer, I simply resized it to a set size when the constructor was called:

buffer.resize(capacity);

Then, whenever the bufferhead or bufferTail would need to get incremented past bufferCapacity-1 (because indexes for
capacity x are 0-(x-1)) I would just set it back to 0 using an if statement.
Here is the excerpt of code that is used for bufferTail. It is similarly implemented for bufferHead in a different function.

 // loops around if capacity is reached. indexes are 0 to capacity-1,
  // so if bufferTail = capacity-1, then we just inserted into the last location
  if (bufferTail == bufferCapacity-1) {
    bufferTail = 0;
  } else {
    bufferTail++;
  }
  

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/
Yes I completed the whole assignment. Everything is working. I ran several tests in a separate file that I don't plan
to attach, but I filled and printed out entire ring buffers of varying sizes. The boost testing also helped me be sure
that I was handling edge cases in a proper manner.




/**********************************************************************
 *  Does your CircularBuffer implementation pass the unit tests?
 *  Indicate yes or no, and explain how you know that it does or does not.
 **********************************************************************/
My Circular Buffer implementation does pass the unit tests. It throws errors at the right times
and when items are peeked or dequeued, the functions also return the right values.




/**********************************************************************
 *  Explain the time and space performance of your RingBuffer
 *	implementation
 **********************************************************************/
Note: The Header says RingBuffer, but I am assuming that they mean CircularBuffer.

Time Performance:
For many functions in the CircularBuffer, the time performance is O(1). This includes functions like 
enqueue, dequeue, size, peek, isEmpty, and isFull. These are because a lot of it is simply relying on O(1) statements
such as if statements to simply check conditions or set the value of an index to a given value. 

The constructor for the CircularBuffer, however, does run in O(n) time. This mainly comes from the vector resize that is
of O(n) time complexity.

Space Performance:
The whole CircularBuffer class has O(n) space complexity once again because of the vector implementation. The vector
is set to the size of the capacity, which means for a size of n objects, the vector must hold space for all n of those 
objects. As for individual functions, they do not really add a noticable amount of space as they mostly rely on fixed
amounts here and there and do not depend on what is being added. 



/**********************************************************************
 *  List whatever help (if any) you received from lab TAs,
 *  classmates, or anyone else.
 **********************************************************************/
None


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
I had issues with cpplint errors, as the header one would persist (my testing, workarounds, and not using the 
workarounds are listed in the other comments section). Otherwise, no significant problems.


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
I did try to get my CircularBuffer.cpp to pass the cpplint. I got rid of all of the errors except for the header path
error. I tried to use // NOLINT to suppress the error (I left this in just in case it does work for you), but for some
reason it did not actually do so, even when I experimented using // NOLINT(*) and // NOLINT(build/include) (NOLINT(*)
is to suppress all errors on that line and NOLINT(build/include) is for the specific error that is persisting).

I have a commented include directive (that had to get split up due to the cpplint length error) that did work just fine
with my code on the uml server. However, I am not sure that the grader would have access to that path and that would
cause my program to throw an error due to not finding the header file, so I did not acutally use it.

I was also able to get the error to disappear by changing the include to CircularBuffer.hpp and changing the header file
to that fie type to match. However, the PDF says specifically to submit a CircularBuffer.h, so I couldn't acutally keep
that file type without losing points.