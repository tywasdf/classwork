/*
Troy Wang
Comp 2040
PS3a
*/

#ifndef CIRCULARBUFFER_H
#define CIRCULARBUFFER_H

#include <stdint.h>
#include <vector>

class CircularBuffer{
  public:
    // required constructor listed in pdf
    CircularBuffer(int capacity);
    
    // required functions listed in pdf
    int size();
    bool isEmpty();
    bool isFull();
    void enqueue(int16_t x);
    int16_t dequeue();
    int16_t peek();

  private:
  // private member variables 
  int bufferTail;
  int bufferHead;
  int bufferCapacity;
  int bufferSize;
  // using vector to hold the ring buffer
  std::vector<int16_t> buffer;
};

#endif //CIRCULARBUFFER_H