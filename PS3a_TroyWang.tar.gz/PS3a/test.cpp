// Copyright 2020 Troy Wang
// test.cpp for PS3a


#include <iostream>
#include <stdexcept>

#include "CircularBuffer.h"

#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE Main
#include <boost/test/included/unit_test.hpp>


BOOST_AUTO_TEST_CASE(constructors ) {
  // tests negative number in constructor. expects error thrown
  BOOST_REQUIRE_THROW(CircularBuffer cTest(-5), std::invalid_argument);
  // tests 0 in constructor. expects error thrown
  BOOST_REQUIRE_THROW(CircularBuffer cTest(0), std::invalid_argument);
  // tests 1 in constructor. expects error thrown
  BOOST_REQUIRE_THROW(CircularBuffer cTest(1), std::invalid_argument);

  // tests an expected input into the constructor. no error should be thrown
  BOOST_REQUIRE_NO_THROW(CircularBuffer cTest(10));
  // tests an expected input into the constructor. no error should be thrown
  BOOST_REQUIRE_NO_THROW(CircularBuffer cTest(20));
  // tests an expected input into the constructor. no error should be thrown
  BOOST_REQUIRE_NO_THROW(CircularBuffer cTest(37));
}

BOOST_AUTO_TEST_CASE(ring_buffer_modification ) {
  CircularBuffer test(10);
  // check functions on empty buffer
  BOOST_REQUIRE_THROW(test.peek(), std::runtime_error);
  BOOST_REQUIRE_THROW(test.dequeue(), std::runtime_error);
  BOOST_REQUIRE(test.isEmpty() == true);
  BOOST_REQUIRE(test.isFull() == false);
  BOOST_REQUIRE(test.size() == 0);
  // add 5 elements to buffer
  BOOST_REQUIRE_NO_THROW(test.enqueue(5));
  BOOST_REQUIRE_NO_THROW(test.enqueue(6));
  BOOST_REQUIRE_NO_THROW(test.enqueue(7));
  BOOST_REQUIRE_NO_THROW(test.enqueue(8));
  BOOST_REQUIRE_NO_THROW(test.enqueue(9));

  // check peek and dequeue on buffer with elements. should return/pop head.
  BOOST_REQUIRE(test.size() == 5);
  BOOST_REQUIRE(test.peek() == 5);
  BOOST_REQUIRE(test.dequeue() == 5);

  // check to make sure size went down after dequeue and that isEmpty is false
  BOOST_REQUIRE(test.size() == 4);
  BOOST_REQUIRE(test.isEmpty() == false);
  BOOST_REQUIRE(test.isFull() == false);

  // add 2 more elements to buffer
  BOOST_REQUIRE_NO_THROW(test.enqueue(10));
  BOOST_REQUIRE_NO_THROW(test.enqueue(11));

  // double check peek and dequeue
  BOOST_REQUIRE(test.peek() == 6);
  BOOST_REQUIRE(test.dequeue() == 6);

  // add elements to put size to capcaity
  BOOST_REQUIRE_NO_THROW(test.enqueue(12));
  BOOST_REQUIRE_NO_THROW(test.enqueue(13));

  // Test the Size function some more
  BOOST_REQUIRE(test.size() == 7);
  BOOST_REQUIRE_NO_THROW(test.enqueue(14));
  BOOST_REQUIRE_NO_THROW(test.enqueue(15));
  BOOST_REQUIRE_NO_THROW(test.enqueue(16));

  // check isEmpty and isFull
  BOOST_REQUIRE(test.isEmpty() == false);
  BOOST_REQUIRE(test.isFull() == true);

  // 12 total elements added, but 2 popped off
  // buffer is now full, so adding another should throw error
  BOOST_REQUIRE_THROW(test.enqueue(17), std::runtime_error);
}
