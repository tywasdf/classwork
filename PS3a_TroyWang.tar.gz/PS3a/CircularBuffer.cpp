/*
Copyright 2020 Troy Wang
Troy Wang
Comp 2040
PS3a
*/

// This include is used to make cpplint shush about including the header file,
// But I am not sure it will work for the grader so i will comment it out
// #include "/usr/cs/undergrad/2021/
// twang1/Fall2020/COMP2040/PS3a/CircularBuffer.h"

#include "CircularBuffer.h"  // NOLINT
#include <stdexcept>

CircularBuffer::CircularBuffer(int capacity) {
  // Have capacity <= 1 becuase algorithm requires 2 items.
  if (capacity <= 1) {
    throw std::invalid_argument
      ("CircularBuffer constructor: capacity must be greater than zero");
  }
  bufferCapacity = capacity;
  bufferSize = 0;
  bufferHead = 0;
  bufferTail = 0;
  buffer.resize(capacity);
}

// required functions in pdf
int CircularBuffer::size() {
  return bufferSize;
}

bool CircularBuffer::isEmpty() {
  if (bufferSize == 0) {
     return true;
  }
  return false;
}

bool CircularBuffer::isFull() {
  if (bufferSize == bufferCapacity) {
    return true;
  }
  return false;
}

void CircularBuffer::enqueue(int16_t x) {
  if (isFull()) {
    throw std::runtime_error("enqueue: can't enqueue into a full ring");
  }

  buffer[bufferTail] = x;

  // loops around if capacity is reached. indexes are 0 to capacity-1,
  // so if bufferTail = capacity-1, then we just inserted into the last location
  if (bufferTail == bufferCapacity-1) {
    bufferTail = 0;
  } else {
    bufferTail++;
  }
  bufferSize++;
}

int16_t CircularBuffer::dequeue() {
  if (isEmpty()) {
    throw std::runtime_error("dequeue: can't dequeue from an empty ring");
  }

  // this should make sure bufferHead never reaches out of index.
  if (bufferHead == bufferCapacity-1) {
    bufferHead = 0;
    bufferSize--;
    return buffer[bufferCapacity-1];
  }

  // if we don't need to worry about bufferHead going out of index,
  // just do things normally.
  bufferSize--;
  return buffer[bufferHead++];
}

int16_t CircularBuffer::peek() {
  if (isEmpty()) {
    throw std::runtime_error("peek: can't peeke from an empty ring");
  }
  // bufferHead should never get out of index, so we can just check it.
  return buffer[bufferHead];
}
