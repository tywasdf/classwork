/**********************************************************************
 *  readme.txt template                                                   
 *  PS6 Kronos 
 **********************************************************************/

Name: Troy Wang


Hours to complete assignment:2 hours


/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/
I was able to complete the whole assignment. I think everything is working. When my program is run,
the output data is similar to that of the decive5_intouch.log.rpt that we were given, minus the formatting
done to make it match how it was described in the pdf (all one line, no time for boot end, etc.)


/**********************************************************************
 *  Copy here all regex's you created for parsing the file, 
 *  and explain individually what each ones does.
 **********************************************************************/
 Here is the code for my regex: 
 
// setup dateTime for regex
	string dateTime("([0-9]{4}-[0-9]{1,2}-[0-9]{1,2}) ([0-9]{2}:[0-9]{2}:[0-9]{2})");
	
	// create lambda expression to automatically include dateTime at beginning of regex
  auto make_regex = [dateTime](string a){
    return boost::regex(dateTime + a);
  };

	// create regex
  boost::regex boot = make_regex(".*(log.c.166).*");
	boost::regex end = make_regex(".*oejs.AbstractConnector:Started SelectChannelConnector@0.0.0.0:9080");

-------------------------------------------------------------------------------------------------------------
so I am making 2 regex here: boot and end.

Since both of these have similar starts (they both include the date and time) I created a string that contains the regex
for that format ####-#(#)-#(#) ##:##:## where the # in parenthesis are optional and # represents a numerical digit.
 
I then created a lambda expression to just tack that regex at the beginning of whatever string I wanted and make the
entirity a regex.
 
The string that I added to make boot accepts anything before (log.c.166) and anything after it. 
So the entirity of the boot regex accepts the date and Time, then any amount of characters, then (log.c.166),
and any amount of characters.

The string that I added to make end acceps anything before 
oejs.AbstractConnector:Started SelectChannelConnector@0.0.0.0:9080
So the entirity of the end regex accepts the date and time, then any amount of characters, then 
oejs.AbstractConnector:Started SelectChannelConnector@0.0.0.0:9080


/**********************************************************************
 *  Describe your overall approach for solving the problem.
 *  100-200 words.
 **********************************************************************/

I looked at this problem and realized that we really mostly only care if we're booting. After all, consecutive end boots
don't constitute a failure, since it is only consecutive start boots that result in failure.

So I ignored everything unless it matched the boot and end regexes. 
If it matched the boot regex:
   1. if already booting, report a failure
   2. report info for new boot.
If it matched the end regex:
   1. if booting, report success and elapsed time

As you can see, I ignore the end regex if I'm not already booting, but always log the information of the boot regex
regardless of whether I'm already booting or not.


/**********************************************************************
 *  Did you use lambda expression? If yes describe there.
 **********************************************************************/
Yes, I used a lambda expression as described above when talking about my regexes. 

All I did was a lambda expression to attach the dateTime string that held the regex to any given string that I wanted 
to be apart of the regex.


/**********************************************************************
 *  List whatever help (if any) you received from TAs,
 *  classmates, or anyone else.
 **********************************************************************/
None


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
None


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
None
