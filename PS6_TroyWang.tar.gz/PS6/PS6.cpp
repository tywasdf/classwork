// Copyright 2020 Troy Wang

#include <iostream>
#include <string>
#include <fstream>
#include <boost/regex.hpp>
#include "boost/date_time/gregorian/gregorian.hpp"
#include "boost/date_time/posix_time/posix_time.hpp"

using std::cout;
using std::cin;
using std::endl;
using std::string;

using boost::gregorian::date;
using boost::gregorian::from_simple_string;
using boost::gregorian::date_period;
using boost::gregorian::date_duration;

using boost::posix_time::ptime;
using boost::posix_time::time_duration;
using boost::posix_time::time_from_string;

int main(int argc, char* argv[]) {
  if (argc !=2) {
    throw std::invalid_argument("There should only be 2 arguments!");
  }

  // open log file
  std::fstream readLog(argv[1], std::fstream::in);
  if (!readLog.is_open()) {
    throw std::runtime_error("unable to open file");
  }

  // create report file
  string reportName(string(argv[1]) + ".rpt");
  std::fstream reportFile(reportName.c_str(), std::fstream::out);

  // setup dateTime for regex
  string dateTime("([0-9]{4}-[0-9]{1,2}-[0-9]{1,2}) ([0-9]{2}:[0-9]{2}:[0-9]{2})"); // NOLINT

  // create lambda expression to automatically include
  // dateTime at beginning of regex
  auto make_regex = [dateTime](string a){
    return boost::regex(dateTime + a);
  };

  // create regex
  boost::regex boot = make_regex(".*(log.c.166).*");
  boost::regex end = make_regex(".*oejs.AbstractConnector:Started SelectChannelConnector@0.0.0.0:9080"); // NOLINT

  // hold matches
  boost::smatch matches;

  // create string to store line in from file
  string line;

  // create line number counter
  int lineNumber = 1;

  // create boolean to remember if booting
  bool isBooting = false;

  // create time variables for time calculation
  ptime startTime, endTime;

  // go through file until EOF
  while (getline(readLog, line)) {
    if (regex_match(line, matches, boot)) {
      // set start time
      startTime = time_from_string(matches[1].str() + " " + matches[2].str());

      // if already booting, we tried to start another boot so first one failed
      if (isBooting) {
        reportFile << " failure\n";
      }
      // print line number and start time.
      reportFile << lineNumber << " (log.c.166) server started ";
      reportFile << startTime;
      isBooting = true;

    } else if (regex_match(line, matches, end)) {
      endTime = time_from_string(matches[1].str() + " " + matches[2].str());
      // only print stuff if we are booting
      if (isBooting) {
        reportFile << " success elapsed time: ";
        reportFile << (endTime - startTime).total_milliseconds() << " ms\n";
        isBooting = false;
      }
    }
    // increment line number
    ++lineNumber;
  }
  return 0;
}
