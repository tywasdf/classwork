/*
Troy Wang
Comp 2040
PS2a
*/

#include "Universe.hpp"


universe::universe(){
  return;
}

universe::universe(float radius){
  universeRadius = radius;
}

//constructor for taking in input from txt doc.
universe::universe(int numOfCelestialBodies, float radius){

  universeRadius = radius;

  //for loop to collect data for the number of celestial bodies.
  for(int i=0; i<numOfCelestialBodies; i++){
    std::shared_ptr<celestialBody> temp = std::make_shared<celestialBody> ();
    std::cin >> *temp;

    //calculate initial position for all bodies as we loop through
    temp->set_position(radius);
    
    //add the body to the vector
    celestialBodies.push_back(temp);
  
    //used for testing
    //std::cout << *temp;
  }
}

//sets the radius if we need to.
void universe::set_radius(float radius){
  universeRadius = radius;
  return;
}

//gets radius
double universe::get_radius(){
  return universeRadius;
}

//uses an iterator to go through and set position of each celestialBody
void universe::set_position(sf::Vector2u windowSize){
  for(auto it = celestialBodies.begin(); it != celestialBodies.end(); ++it){
    (**it).set_position(universeRadius, windowSize);
  }
}


//uses an iterator to go through and draw each celestialBody
void universe::draw(sf::RenderTarget& target) const{
  for(auto it = celestialBodies.begin(); it != celestialBodies.end(); ++it){
    target.draw(**it);
  }
}

//print function for testing.
void universe::print (){
  for(auto it = celestialBodies.begin(); it != celestialBodies.end(); ++it){
    std::cout << **it;
  }
}

//changes position of celestialBodies depending on velocity and time step(deltaT).
void universe::step(double deltaT){
  this->calculate_velocities(deltaT);
 // std::cout << "NEW PHASE" << std::endl;
  
  for(auto it = celestialBodies.begin(); it != celestialBodies.end(); ++it){
    (**it).set_positionX((**it).get_positionX() + ((**it).get_velocityX() * deltaT));  
    (**it).set_positionY((**it).get_positionY() + ((**it).get_velocityY() * deltaT));
  }
 // this->print();
}

void universe::calculate_velocities(double deltaT){
  const double gravity = 6.67e-11; 
  //nested loops to be able to compare two celestialBodies together. second loop only goes to first iterator because all calculations can be negated and applied to other celestialBody. This way we can go through less of the nested loop but still hit everything
  for(auto it = celestialBodies.begin(); it != celestialBodies.end(); ++it){
    for(auto it2 = celestialBodies.rbegin(); *it2 != *it; ++it2){    
    
      double distX = (*it2)->get_positionX() - (*it)->get_positionX();          
      double distY = (*it2)->get_positionY() - (*it)->get_positionY();
      //std::cout <<distX << distY;
      double distSQ = pow(distX,2) + pow(distY,2);                 //calculate r^2
      double dist = sqrt(distSQ);                                  //calculate r
      double force = (gravity* (**it).get_mass() * (**it2).get_mass())/distSQ;  //calulate force (g*m1*m2)/r    
      double forceX = force* (distX/dist);          //force ratio for x
      double forceY = force* (distY/dist);          //force ratio for y
      double accelXit = forceX/(**it).get_mass();        //a = F/m
      double accelYit = forceY/(**it).get_mass();        //a = f/m
      double velocityXitChange = accelXit * deltaT;      //v = deltaT*a
      double velocityYitChange = accelYit * deltaT;      //v = deltaT*a
      double accelXit2 = -1*forceX/(**it2).get_mass();  //negate for it2 because we have distances based on it, not it2
      double accelYit2 = -1*forceY/(**it2).get_mass();  //negate for it2 because we have distances based on it, not it2
      double velocityXit2Change = accelXit2 * deltaT;  //already negated as accel was negated, so dont need to negate again.
      double velocityYit2Change = accelYit2 * deltaT;  //already negated as accel was negated, so dont need to negate again.
      //std::cout << velocityXitChange << velocityYitChange<< velocityXit2Change<<velocityYit2Change;
      (**it).set_velocityX((**it).get_velocityX() + velocityXitChange);      //set X position for it
      (**it).set_velocityY((**it).get_velocityY() + velocityYitChange);      //set Y position for it
      (**it2).set_velocityX((**it2).get_velocityX() + velocityXit2Change);    //set X position for it2
      (**it2).set_velocityY((**it2).get_velocityY() + velocityYit2Change);    //set Y position for it2
    }
  }
}


