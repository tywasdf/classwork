/*
Troy Wang
Comp 2040
PS2a
*/

#include "Universe.hpp"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

int main(int argc, char* argv[]){

  std::string::size_type sz; //for stod use
  
  //assign the parameters to doubles.
  double T = std::stod(argv[1], &sz);
  double deltaT = std::stod(argv[2], &sz);
  double timeElapsed = 0;
  
  //std::cout << T << " " << deltaT; for testing
  int numPlanets;
  float radius;
  std::cin >> numPlanets >> radius;
  

  universe galaxy = universe(numPlanets, radius);
  
  
  //galaxy.step(deltaT);
  //std::cout << "HIHIHIHIHIHIHI" << std::endl;
  //galaxy.step(deltaT);

  sf::RenderWindow window(sf::VideoMode(defaultWindowSize.x, defaultWindowSize.y), "The Galaxy");
  
  window.setFramerateLimit(60);
  
  //create image for background
  sf::Image background;
  
  //if load fails, throw error
  if(!background.loadFromFile("space.png")){
     throw std::invalid_argument("no file for celestialImage");
  }
  
  //creating texture for background
  sf::Texture backgroundTexture;
  backgroundTexture.loadFromImage(background);
  
  //creating sprite for background
  sf::Sprite backgroundSprite;
  backgroundSprite.setTexture(backgroundTexture);

  //create text.
  sf::Font timeFont;
  timeFont.loadFromFile("arial.ttf");
  
  sf::Text timeDisplay;
  timeDisplay.setFont(timeFont);
  
  //make time legible
  timeDisplay.setCharacterSize(14);
  timeDisplay.setFillColor(sf::Color::White);
  
  //create music (which I did not make. I found it royalty free. see readme.)
  sf::Music music;
  if(!music.openFromFile("Joey Pecoraro - Your Favorite Place.flac")){
    throw std::invalid_argument("no file for music");
  }
  
  //play music. This may cause some delay due to needing to open it. 
  music.play();
  //std::cout << "music playing: " << (music.getStatus() == sf::SoundSource::Status::Playing) <<std::endl; for testing if music is actually playing since i can't hear it off of the uml server.
  
  while (window.isOpen()){
        // Process events
        sf::Event event;
        while (window.pollEvent(event)){
            // Close window: exit
            if (event.type == sf::Event::Closed){
                window.close();
            }
        }
        window.clear();
        
      
        //draw background
        window.draw(backgroundSprite);
        
        
  
        //function in universe class to draw all celestialBodies in universe object uses target.draw() in the function.
        galaxy.draw(window);
        
        //check to make sure elapsed time does not go over T.
        if(timeElapsed+ deltaT <= T){
          galaxy.step(deltaT);
          galaxy.set_position(window.getSize());
          timeElapsed += deltaT;
          timeDisplay.setString("Elapsed Time: " + std::to_string(timeElapsed));
        }
        
        //draw time Display onto window.
        window.draw(timeDisplay);
        
        //std::cout << ++count<< std::endl;
        window.display();
    }
    
    galaxy.print();  //prints final state of the universe.
    
  return 0;
}