/**********************************************************************
 *  N-Body Simulation ps2b-readme.txt template
 **********************************************************************/

Name: Troy Wang
Hours to complete assignment: 3 hours

/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
 ----------------------------FROM PS2a-------------------------------------------------
This program displays the planets in a sfml window. It gets the information from the planets.txt text file (when input is redirected to planets.txt) and creates celestialBody objects.
In order to collect the information, the >> operator was overloaded to facilitate the creation of the celestialBody objects.

I also created a universe class to hold the celestialBody objects and used that class to also facilitate the drawing of the whole collection. 

----------------------------FOR PS2b-------------------------------------------------
For new additions, I was able to add in stepping through the universe class. Now, based on time elapsed, forces will be calulated and positions of the objects inside of the universe class will be updated. This means that when our window is running, the planets will be moving and rotating around the sun (because the sun does not move enough to visibly change).

I also was able to add in music for mood and text to show time elapsed.

/**********************************************************************
 *  If you created your own universe for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/

I did not create my own universe.


/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/

None.
/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
Originally I had my velocities arranged so that intuitively the y values would increase as the y velocity was going up. However, this causes the planets to rotate in a clockwise direction. To make it match the assignment and rotate counter clockwise. I simply negated the y position ratio in my set_position function. Otherwise, the whole 

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

I did load text to display elapsed time (as mentioned above) and play music for extra credit.

You can't hear the music through the uml cs server, but I did comment out the line I had below the play line that printed music playing: 1 if the music was playing properly.

I would just like to put here that I did not make the music. The music is free to use if you sign up and credit them. 
The youtube video i found the song on is https://www.youtube.com/watch?v=Tk7xUgZIyoM which has a link to the free download. 
I also signed up as a user so that they know I am using their content. (also not monetizing it or planning to distribute it publicly). I also suppose this falls under fair use, but I'm just being safe.
Music by Chillhop Music https://chillhop.com

Once again, I named this ps3b-readme to match what it says at the end of the pdf, but I realize this is for ps2b.