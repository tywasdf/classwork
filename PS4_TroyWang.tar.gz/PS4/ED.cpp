// Copyright 2020 Troy Wang

#include "ED.hpp"
#include <iostream>
#include <exception>
#include <sstream>

ED::ED(std::string stringOne, std::string stringTwo) {
  // store strings
  string1 = stringOne;
  string2 = stringTwo;

  // make matrix size of string1.length+1 x string2.length+1
  for (int i = 0; i <= static_cast<int>(string1.length()); i++) {
    std::vector<int> temp;
    temp.resize(string2.length()+1);
    matrix.push_back(temp);
  }
}

int ED::penalty(char a, char b) {
  return a == b ? 0 : 1;
}

// return smallest value
int ED::min(int a, int b, int c) {
  // if a is smallest or equal to smalles
  if (a <= b && a <= c) {
    return a;
  } else if (b <= c) {  // since a is not smallest, check if b <= c
    return b;
  } else {  // return c because it must be smallest
    return c;
  }
}

// fill out matrix for distances
int ED::OptDistance() {
  int m = string1.length();
  int n = string2.length();

  // fill in right column
  for (int i = 0; i <= m; i++) {
    matrix[i][n] = 2* (m-i);
  }

  // don't have to do when j=n becuase it was set in the previous for loop
  for (int j = 0; j < n; j++) {
    matrix[m][j] = 2*(n-j);
  }

  // start at bottom and go up.
  for (int i = m-1; i >= 0; i--) {
    for (int j = n-1; j >= 0; j--) {
      matrix[i][j] = min(matrix[i+1][j+1] + penalty(string1[i], // NOLINT added for false positive
      string2[j]), matrix[i+1][j]+2, matrix[i][j+1]+2);
    }
  }

  // return the optimal edit distance
  return matrix[0][0];
}

std::string ED::Alignment() {
  std::stringstream returnString;
  int i = 0;
  int j = 0;
  int m = string1.length();
  int n = string2.length();
  int right, diag;
  int penaltyCost = 5;

  // made lambda expressions for each calculated case.
  auto rightCase = [this](int x, int y){return matrix[x+1][y] + 2;};
  auto diagCase = [this](int x, int y, int penaltyCost){
    return matrix[x+1][y+1] + penaltyCost;
  };
  // loop to check when we hit bottom right corner
  while (i < m || j < n) {
    // make the right gap case
    try {
      // right = matrix[i + 1][j] + 2;
      right = rightCase(i, j);
    } catch (std::out_of_range e) {
      right = -1;
    }

    // make diagonal case
    try {
      penaltyCost = penalty(string1[i], string2[j]);
      // diag = matrix[i+1][j+1] + penaltyCost;
      diag = diagCase(i, j, penaltyCost);
    } catch (std::out_of_range e) {
      diag = -1;
    }

    // check if diagonal was optimal
    if (matrix[i][j] == diag) {
      returnString << string1[i] << " " << string2[j]
          << " " << penaltyCost << "\n";
      i++;
      j++;
    } else if (matrix[i][j] == right) {  // check if right was optimal
      returnString << string1[i] << " - 2\n";
      i++;
    } else {  // if diagonal and right weren't optimal, down gap must be
      returnString << "- " << string2[j] << " 2\n";
      j++;
    }
  }

  return returnString.str();
}

void ED::print() {
  for (int i = 0; i < static_cast<int>(matrix.size()); i++) {
    for (int j = 0; j < static_cast<int>(matrix[0].size()); j++) {
      std::cout << matrix[i][j] << "  ";
    }
    std::cout << std::endl;
  }
}
