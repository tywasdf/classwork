/**********************************************************************
 *  readme template                                                   
 *  DNA Sequence Alignment
 **********************************************************************/

Name:Troy Wang

Hours to complete assignment: ~6 hours

/**********************************************************************
* Explain which approach you decided to use when implementing
 * (either recursive with memoization, recursive without memoization,
 * dynamic programming or Hirschberg�s algorithm). Also describe why
 * you chose this approach and what its pros and cons are.
 **********************************************************************/
I decided to use the dynamic programming method for implementation. It seemed a little simpler
overall to implement because we could make the table first and then backtrack to 
figure out the path, but the draw back was that it was N^2 levels of space.
As for speed, it should be a faster than the recursion method after the initial matrix is made.

/**********************************************************************
 * Does your code work correctly with the endgaps7.txt test file? 
 * 
 * This example should require you to insert a gap at the beginning
 * of the Y string and the end of the X string.
 **********************************************************************/
Input:  atattat
	tattata

Expected output:
Edit Distance: 4

a - 2
t t 0
a a 0
t t 0
t t 0
a a 0
t t 0
- a 2

What happened:
my program seg faulted. This occurs during my alignment function. I did notice that my edit distance was 
4. This indicates to me that I am missing the a gap at the end because my alignment starts at (0,0) 
and works its way to the ends of the strings. Since my alignment would notice the early gap, it would hit an 
out of bounds error when it tries to go diagonal at the last gap. This ultimately happens because I only have 
a buffer of 1 more than the string length for each axis, so the first gap immediately consumes that buffer and
there isn't another buffer for the second gap.

/**********************************************************************
 *  How much main memory does your computer have? Typical answers
 *  are 2GB and 4GB. If your machine has 512MB or less, use a cluster
 *  machine for this readme (see the checklist for instructions).
 **********************************************************************/

12GB

/**********************************************************************
 *  For this question assume M=N. Look at your code and determine
 *  approximately how much memory it uses in bytes, as a function of 
 *  N. Give an answer of the form a * N^b for some constants a 
 *  and b, where b is an integer. Note chars are 2 bytes long, and 
 *  ints are 4 bytes long.
 *
 *  Provide a brief explanation.
 *
 *  What is the largest N that your program can handle if it is
 *  limited to 8GB (billion bytes) of memory?
 **********************************************************************/
For context: the size of a vector is 24 bytes. I used a 2D structure of vectors where
the inner vectors held ints.
a =4
b = 2
Equation: 4*N^2
I am choosing 4 for a because it is the size of an int and 2 for b because my matrix is NxN, which means
I store N bits. However, I know this is not correct because this does not account for the vectors that 
I use. I use N+1 vectors (1 vector to hold all the other vectors and N vectors representing rows). My
actual memory usage is 24*(N+1) + 4*N^2.

largest N = 44718
using my actual memory equation, you get the equation 4N^2 + 24N - 7,999,999,976 = 0. Solving for N using the quadratic
equation gives me an answer of ~44718 for N (ignoring the negative answer because that makes no sense), so that would
 be the largest N my program can handle.

/**********************************************************************
 * Run valgrind if you can and attach the output file to your submission. 
 * If you cannot run it, explain why, and list all errors you�re seeing. 
 * If you can run it successfully, does the memory usage nearly match that 
 * found in the question above? 
 * Explain why or why not. 
/**********************************************************************
Yes I ran valgrind. Below is the graph when running through ecoli2500.txt


    MB
24.12^                                          ::::::::::::::::::::::::::::: 
     |            ##############################:                            :
     |           @#                             :                            :
     |          @@#                             :                            :
     |          @@#                             :                            :
     |         @@@#                             :                            :
     |         @@@#                             :                            :
     |        @@@@#                             :                            :
     |        @@@@#                             :                            :
     |       @@@@@#                             :                            :
     |      @@@@@@#                             :                            :
     |      @@@@@@#                             :                            :
     |     @@@@@@@#                             :                            :
     |     @@@@@@@#                             :                            :
     |    @@@@@@@@#                             :                            :
     |   @@@@@@@@@#                             :                            :
     |   @@@@@@@@@#                             :                            :
     |  @@@@@@@@@@#                             :                            :
     |  @@@@@@@@@@#                             :                            :
     | @@@@@@@@@@@#                             :                            :
   0 +----------------------------------------------------------------------->Mi

As you can see in the graph, I am using ~24MB of memory. This is pretty close to what I expected as
the math from above calculates ~25MB of memory used. This is because I accounted for the overhead of the vectors that I
had as well as the ints I was storing. 

/**********************************************************************
 *  For each data file, fill in the edit distance computed by your
 *  program and the amount of time it takes to compute it.
 *  For help on how to do timing, see the checklist (e.g. -Xprof).
 *  If you get an OutOfMemoryError, see the checklist about -Xmx.
 *  If you get "Could not reserve enough space for object heap" or the timing
 *  of these tests takes too long for the last few test cases (N=20000 or higher), 
 *   note this, and skip filling out those rows of the table.
 **********************************************************************/
*Note* I am using -O2 optimization flag

data file           distance       time (seconds)
-------------------------------------------------
ecoli2500.txt		118		0.07521
ecoli5000.txt		160		0.18606
ecoli10000.txt		223		0.452122
ecoli20000.txt		3135		3.113
ecoli50000.txt		--Test took too long-- Virtualmachine killed the program
ecoli100000.txt		--Test took too long-- Virtualmachine killed the program


/*************************************************************************
 *  Here are sample outputs from a run on a different machine for 
 *  comparison.
 ************************************************************************/

data file           distance       time (seconds)
-------------------------------------------------
ecoli2500.txt          118             0.171
ecoli5000.txt          160             0.529
ecoli7000.txt          194             0.990
ecoli10000.txt         223             1.972
ecoli20000.txt         3135            7.730

/**********************************************************************
 *  For this question assume M=N (which is true for the sample files 
 *  above). By applying the doubling method to the data points that you
 *  obtained, estimate the running time of your program in seconds as a 
 *  polynomial function a * N^b of N, where b is an integer.
 *  (If your data seems not to work, describe what went wrong and use 
 *  the sample data instead.)
 *
 *  Provide a brief justification/explanation of how you applied the
 *  doubling method.
 * 
 *  What is the largest N your program can handle if it is limited to 1
 *  day of computation? Assume you have as much main memory as you need.
 **********************************************************************/
a = 2.736 x 10^-8
b = 2

I got this value based on the speed if the ecoli2500.txt run. I knew it was N^2 because my table
is NxN, so I would be making that many. So In order to figure out a, I divided the run time by 2500^2.
If I check with the data from ecoli5000, i get ~2.1 x 10^-8 so the value is pretty close.

My data starts to fall apart around the ecoli20000 mark. Instead of multiplying my time by ~4x, it was multiplied
by ~6x. I suspect that this is because my virtual machine was starting to run out of the allocated ram that my PC
is set to give it (2GB in this case).

largest N = 1,777,046 
To calculate N, We are looking at a 24 hour day, which is 1440 minutes, or 86400 seconds.
using 2.736x10^-8 * N^2 = 86400
N^2 = 3,157,894,736,842.105
N = 1,777,046.633	
**********************************************************************
 *  Did you use the lambda expression in your assignment? If yes, where 
 * (describe a method or provide a lines numbers)
 **********************************************************************/
I did use the lambda expression in my assignment. I used it when I was tracing back through the matrix to find
the alignmnent. I used it when I was setting variables equal to each of the cases. This way I could make a temporary
function outside of my loop but still call it during every loop.

/**********************************************************************
 *  List whatever help (if any) you received from lab TAs, preceptors,
 *  classmates, past COS 126 students, or anyone else.
 **********************************************************************/
None


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
None


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
None.
