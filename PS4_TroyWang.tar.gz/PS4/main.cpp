// Copyright 2020 Troy Wang

#include <iostream>
#include <string>
#include <SFML/System.hpp>
#include "ED.hpp"

int main(int argv, char** argc) {
  sf::Clock clock;
  sf::Time t;

  std::string string1, string2;
  std::cin >> string1 >> string2;
  ED test(string1, string2);
  std::cout << "Edit distance = " << test.OptDistance() << "\n";
  std::cout << test.Alignment();

  t = clock.getElapsedTime();
  std::cout << "Execution time is " << t.asSeconds() << "seconds \n";
  // Edit distance is reprinted for ease of looking at output
  std::cout << "Edit distance = " << test.OptDistance() << "\n";
  return 0;
}
