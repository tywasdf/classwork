#ifndef ED_H
#define ED_H


#include <vector>
#include <string>

class ED{
  public:
    ED(std::string stringOne, std::string stringTwo);
    static int penalty(char a, char b);
    static int min(int a, int b, int c);
    int OptDistance();
    std::string Alignment();
    void print();
  private:
    // 2D vector matrix, so I can use the i,j like coordinates
    std::vector<std::vector<int>> matrix;
    std::string string1;
    std::string string2;

};



#endif //ED_H