#ifndef FIBLFSR_H
#define FIBLFSR_H

#include <string>
#include <stdexcept>

#include <iostream>

class FibLFSR {
    public:
        FibLFSR(std::string seed); // constructor to create LFSR with
        // the given initial seed and tap
        int step(); // simulate one step and return the
        // new bit as 0 or 1
        int generate(int k); // simulate k steps and return
        // k-bit integer
        
        //overloading the << operator for the FibLFSR class
        friend std::ostream& operator<< (std::ostream &out, FibLFSR &a);
        
    private: 
      //storing the register as a string.
        std::string bitString;
        
    
};

#endif //FIBLFSR_H