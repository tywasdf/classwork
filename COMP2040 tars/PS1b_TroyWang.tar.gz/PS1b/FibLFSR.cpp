#include <iostream>
#include <string>
#include <stdexcept>
#include "FibLFSR.h"

FibLFSR::FibLFSR(std::string seed){
    if(seed.length() == 16){ //makes sure that the length of the seed is 16/
        for(char& c : seed){ 
            if(c != '0' && c != '1'){ //checks the characters to make sure they are 0's and 1's
                  throw std::invalid_argument("this is not a string of 0's and 1's"); //exception thrown if characters are not 0's and 1's 
            }
        }
        //sets the seed to bitString variable.
        bitString = seed;
    }
    else{
        throw std::length_error("length is not 16 bits.");
    }
}

int FibLFSR::step(){
    //xor equation of ((left most XOR 13th bit) XOR 12th bit)XOR 10th bit). since the first two are both characters, i'm not "-'0'" them to get their value as an int because it wouldn't change the XOR value. However, XORing 0000000001 with '0' would give a wildly different value, so I "-'0'" to change their value to their numerical value at the bit level.
    int add = ((bitString.at(0)^(bitString.at(2))^(bitString.at(3)-'0'))^(bitString.at(5)-'0'));
    bitString = bitString.substr(1) + std::to_string(add); //add the result while ditching the most significant bit.
 //   std::cout << bitString << " " << add << std::endl;
    return add;
}

int FibLFSR::generate(int k){
    if(k>16 || k<0){ // checks to make sure we aren't checking more bits than the register is. also negative numbers make no sense, so those are checked for as well.
        throw std::invalid_argument( "k is larger than register or negative"); //exception thrown if k is larger than the register or negative.
    }
    int count = 0;
    for(int i = 0; i<k; i++){
        count = count*2 + step();
    }
//    std::cout << bitString << " " << count << std::endl;
    return count;
}

//prints out the current bitString saved in LFSR
std::ostream& operator<< (std::ostream &out, FibLFSR &a)
{
  out << a.bitString;
  return out;
}
