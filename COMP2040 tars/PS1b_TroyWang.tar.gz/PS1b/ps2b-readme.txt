/**********************************************************************
 *  Linear Feedback Shift Register (part B) ps1b-readme.txt template
 **********************************************************************/

Name: Troy Wang
Hours to complete assignment:3
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
I used the FibLFSR implementation that we made in PS1a to encode an image and show it on SFML. If you take the output image and the same seed for the FibLFSR, you can successfully decode the image. I made two separate windows (one for each image). For my screenshots, I realligned the windows to put them next to each other and so that I could show the whole image, but otherwise nothing was changed. Each window is labeled with what it is showing (one is called input image and the other is called output image). 


/**********************************************************************
 *  If you did any implementation for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/
None


/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
None

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
I had a small problem where I was accidentally trying to create an image for the outputImage variable with a nonexistant output file, but I realized that I actually had meant to make it from the inputFile. That caused me a lot of grief. Also, I do most of my coding on the uml server, so I was trying to connect with the ssh and for some reason it would occasionally run slow and give me an error saying I didn't have authorization to run X11, which was used to open the sfml windows. 

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
 
I named the readme file ps2b-readme.txt since the document on blackboard said to. I realize though, that the assignment is actually ps1b.