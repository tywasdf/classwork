/*
Troy Wang
Comp2040
ps0
*/

#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "FibLFSR.h"

sf::Image transform(sf::Image& image, FibLFSR* randomizer);

sf::Image transform(sf::Image& image, FibLFSR* randomizer){
  sf::Color p;
  sf::Vector2u size = image.getSize();
  // Randomize the bits in the image
  for(int x= 0; x < (signed)size.x; x++){
    for(int y = 0; y < (signed)size.y; y++){
    // Get the current pixel from the input image
    p = image.getPixel(x, y);

    // XOR the pixels
    p.r = p.r ^ randomizer->generate(8);
    p.g = p.g ^ randomizer->generate(8);
    p.b = p.b ^ randomizer->generate(8);
  
    // Modify just the output image
    image.setPixel(x, y, p);
    }
  }
  return image;
}


int main(int argc, char* argv[]){
    //check that 4 command line inputs were entered
    if(argc != 4){
      throw std::length_error ("There are not 4 command line arguments. Please use ./executable inputImage outputImage seed");
    }
    
    // Create the input image
    sf::Image inputImage;
    if (!inputImage.loadFromFile(argv[1])){
      throw std::invalid_argument("This is not a valid image file");
    }

    // Create the output image
    sf::Image outputImage;
    if (!outputImage.loadFromFile(argv[1])){
      throw std::invalid_argument("This is not a valid image file");
    }
    
    //Create the  FibLFSR randomizer
    FibLFSR randomizer(argv[3]);
    
    // Create Vector24 variable to get dimensions for windows
    sf::Vector2u size = inputImage.getSize();
    
    // Modify the output file and save it
    if (!(transform(outputImage, &randomizer).saveToFile(argv[2]))){
      return -1;
    }
      
    //make window for original image
    sf::RenderWindow original(sf::VideoMode(size.x, size.y), "Input Image");
    
    //make window for transformed image
    sf::RenderWindow transformed(sf::VideoMode(size.x, size.y), "Output Image");
    
    
    //Create texture for input for original
    sf::Texture inputTexture;
    inputTexture.loadFromImage(inputImage);
    
    //Create sprite from texture for original
    sf::Sprite inputSprite;
    inputSprite.setTexture(inputTexture);
    
    //Create texture for input for transformed
    sf::Texture outputTexture;
    outputTexture.loadFromImage(outputImage);
    
    //Create sprite from texture for transformed
    sf::Sprite outputSprite;
    outputSprite.setTexture(outputTexture);
    
    // Start the game loop
    while (original.isOpen() && transformed.isOpen())
  {
    sf::Event event;

    while (original.pollEvent(event))
    {
      if (event.type == sf::Event::Closed)
      {
        original.close();
      }
    }

    while (transformed.pollEvent(event))
    {
      if (event.type == sf::Event::Closed)
      {
        transformed.close();
      }
    }

    original.clear();
    original.draw(inputSprite);    // Input image
    original.display();

    transformed.clear();
    transformed.draw(outputSprite);    // Output image
    transformed.display();
  }
  
  
    return EXIT_SUCCESS;
}
