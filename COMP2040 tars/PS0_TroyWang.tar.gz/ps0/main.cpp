/*
Troy Wang
Comp2040
ps0
*/

#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
int main()
{
    // Create the main window
    sf::RenderWindow window(sf::VideoMode(800, 600), "SFML window");
    //make green circle
    sf::CircleShape shape(100.f);
    shape.setFillColor(sf::Color::Green);
    // Load a sprite to display
    sf::Texture texture;
    if (!texture.loadFromFile("sprite.png"))
        return EXIT_FAILURE;
    sf::Sprite sprite(texture);
    /*
    // Create a graphical text to display
    sf::Font font;
    if (!font.loadFromFile("arial.ttf"))
        return EXIT_FAILURE;
    sf::Text text("Use Arrow keys to move sprite", font, 50);
    */

    // showSprite variable to maintain toggle outside of game loop.
    bool showSprite = true;
    
    // Start the game loop
    while (window.isOpen())
    {
        // Process events
        sf::Event event;
        while (window.pollEvent(event))
        {
            //move sprite when arrow keys are pressed 
            if(event.type == sf::Event::KeyPressed){
              switch(event.key.code){
                case sf::Keyboard::Up:
                  if(showSprite)
                    sprite.move(0,-3);
                  break;
                case sf::Keyboard::Down:
                  if(showSprite)
                    sprite.move(0,3);
                  break;
                case sf::Keyboard::Right:
                  if(showSprite)
                    sprite.move(5,0);
                  break;
                case sf::Keyboard::Left:
                  if(showSprite)
                    sprite.move(-5,0);
                  break;
                case sf::Keyboard::Space:
                  showSprite = showSprite == true ? false : true;
                  break;
                default:
                  break;
              }
            }
            //
            if(event.type == sf::Event::MouseWheelScrolled){
              if(showSprite){
                if(event.mouseWheelScroll.delta > 0)
                  sprite.scale(1.1, 1.1);
                else{
                  sprite.scale(0.9,0.9);
                }
              }
            }
            // Close window: exit
            if (event.type == sf::Event::Closed)
                window.close();
        }
        // Clear screen
        window.clear();
        //draw circle
        window.draw(shape);
        /*
        // Draw the string
        window.draw(text);
        */
        // Draw the sprite
        if(showSprite)
          window.draw(sprite);
        // Update the window
        window.display();
    }
    return EXIT_SUCCESS;
}
