/**********************************************************************
 *  ps0-readme template                                                   
 *  Hello World Assignment                       
 **********************************************************************/

Your name: Troy Wang

Operating system you're using (Linux, OS X, or Windows): Windows 

IDE or text editor you're using: Vim or Notepad or Notepad++

Hours to complete assignment: 2

/**********************************************************************
 *  List some information (optionally) to help me get to know you.
 **********************************************************************/

Did you take Computing I at UML?

 - If yes, who was your instructor? Yes, Professor Mwaura

 - If no, where did you transfer from?


/**********************************************************************
 *  Part of Assignment 0 is to read the collaboration policy in syllabus.
 *  
 *  If you haven't done this, please do so now.
 *
 *  Read the University policy Academic Integrity,
 *  and answer the following question:
 *
 * There are six examples of academic misconduct, labeled (a) through
 * (f). Other than (a), "Seeks to claim credit for the work or efforts
 * of another without authorization or citation," which of these do you
 * think would most apply to this class, and why? Write approx. 100-200
 * words.
 *
 * Note: there is no single correct answer to this. I am looking for
 * your opinion.

I think that the examples D, E, and F will all strongly apply to this course. I remember group work being mentioned during the first lecture, so when we start doing that work, having group members who do a disproportionate amoung of work will be infracting
 on these rules. A student who does not do their fair share of work will not only be impacting the academic work of their peers, but also be attempting to make it seem like they earned their grade if nothing is said about the work distribution when the project
 is turned in. However, this also means that the group members who do not speak up about the unfair work distribution will also be participating in academic misconduct because they have not mentioned anything about it and are therefore helping the inactive group member. 
 **********************************************************************/



/**********************************************************************
 *  List whatever help (if any) you received from TAs, the instructor,
 *  classmates, or anyone else.
 **********************************************************************/



/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
On implementing the mouse scroll wheel event, I found out I was actually initially using the depreciated MouseWheelMoved event instead of the more current MouseWheelScrolled. This took me a while to realize, but after I realized it the fix was simple as the two event
 types are implemented similarly.


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

Additional features: Mouse wheel scroll zooms the size of the sprite. Scrolling up enlarges the sprite and scrolling down decreases the sprite.

Pressing space also toggles showing the sprite. Any events that occur while sprite is toggled off will not affect the sprite.
