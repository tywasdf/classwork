

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>

#include <math.h>
#include <limits.h>

#include <iostream>
#include <string>
#include <exception>
#include <stdexcept>
#include <vector>

#include "CircleBuffer.h"
#include "StringSound.h"



std::vector<sf::Int16> makeSamples(StringSound gs, bool dif) {
  std::vector<sf::Int16> samples;

  gs.pluck();
  int duration = 8;  // seconds
  int i;
  for (i= 0; i < SAMPLES_PER_SEC * duration; i++) {
    gs.tic();
    samples.push_back(gs.sample());
  }
  return samples;
}

int main() {
  sf::RenderWindow window(sf::VideoMode(300, 200), "SFML Plucked String Sound Lite");
  sf::Event event;

  double freq;

  std::vector<std::vector<sf::Int16>> samples(37);
  std::vector<sf::SoundBuffer> soundBuffers(37);
  std::vector<sf::Sound> sounds(37);

  std::vector<std::vector<sf::Int16>> samples2(37);
  std::vector<sf::SoundBuffer> soundBuffers2(37);
  std::vector<sf::Sound> sounds2(37);

  // create a string with the keyboard keys
  std::string keyboard = "q2we4r5ty7u8i9op-[=zxdcfvgbnjmk,.;/' ";

  //make frequencies for the keyboard.
  for(int i=0; i<37; i++){
    // Use formula in pdf to calculate frequency
    freq = 440*pow(2,((i-24)/12.0));
    StringSound temp = StringSound(freq);
    // use the StringSound to fill the samples vector in that index
    samples[i] = makeSamples(temp, false);

    if(!soundBuffers[i].loadFromSamples(&samples[i][0], samples[i].size(), 2, 44100)){
        throw std::runtime_error("Could not load soundBuffers from samples");
    }
    sounds[i].setBuffer(soundBuffers[i]);
  }

  while (window.isOpen()) {
    while (window.pollEvent(event)) {
      //check if event is unicode character (because our entire keyboard consists of unicode characters)
      //better than doing a switch for each key
      if(event.type == sf::Event::TextEntered){
        // ASCII is a subset of unicode, only need to deal with ASCII chars
        if(event.text.unicode < 128){
          // convert unicode to ascii
          char key = (char) (event.text.unicode);

          for(int i = 0; i<37; i++){
            if(keyboard[i] == key){
              sounds[i].play();
              break;
            }
          }
        }
      }
      // Close window: exit
      if (event.type == sf::Event::Closed)
        window.close();
    }
    window.clear();
    window.display();
  }
  return 0;
}
