#ifndef STRINGSOUND_H
#define STRINGSOUND_H

#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>
#include <vector>
#include <memory>
#include "CircleBuffer.h"

#define SAMPLES_PER_SEC 44100
#define CONCERT_A 220.0

class StringSound{
	public:
		StringSound(double frequency);
		StringSound(std::vector<sf::Int16> init);
		void pluck();
		void tic();
		sf::Int16 sample();
		int time();
		int getBufferSize();
		~StringSound();
	private:
		int ticsPassed;
		CircleBuffer* buffer;
};




#endif //STRINGSOUND_H
