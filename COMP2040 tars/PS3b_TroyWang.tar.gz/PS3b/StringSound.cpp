//Troy Wang
//PS3b

#include "StringSound.h"
#include <cmath>
#include <random>
#include <exception>

StringSound::StringSound(double frequency){
	ticsPassed = 0;
	// use lambda expression so we don't have to calculate capacity,
	// assign it to a variable, then use it for the constructor.
	//Add exception for when samples/freq <=1
	if(frequency >= 44100 || frequency <=0){
		throw std::invalid_argument
			("Frequency must be between 1 and 44099");
	}
	//int value = ceil(SAMPLES_PER_SEC/frequency);
	buffer = new CircleBuffer([](int samples, int freq){return ceil(samples/freq);}(SAMPLES_PER_SEC, frequency)); 
}

StringSound::StringSound(std::vector<sf::Int16> init){
	buffer = new CircleBuffer(init.size());
	for (auto it = init.begin(); it < init.end(); it++){
		buffer->enqueue((int16_t) *it);
	}

	ticsPassed = 0;
}

void StringSound::pluck(){
	buffer->empty();

	//make random number generator
	std::mt19937 mt(1729);
	std::uniform_int_distribution<int16_t> dist(-32768,32767);
	for(int i =0; i < buffer->capacity(); i++){
		buffer->enqueue(dist(mt));
	}
}

void StringSound::tic(){
	/*	
	// check if buffer size is too small for dequeue + peek
	if(buffer->size()<2){
		throw std::length_error("Buffer is too small, can't tic");
	}
	*/
	// dequeue the first value
	int16_t first = buffer->dequeue();

	// get second value for Karplus-Strong, but don't dequeue	
	int16_t second = buffer->peek();

	// using 0.498 instead of decay factor of 0.996 because i took the 1/2 from the average (of first and second) and multiplied it to the 0.996
	buffer->enqueue((sf::Int16) (0.498*(first+second)));
	ticsPassed++;
}


sf::Int16 StringSound::sample(){
	// check for exception if buffer is too empty
	if(buffer->isEmpty()){
		throw std::length_error("Buffer is too small, can't peek for sample");
	}

	return (sf::Int16) buffer->peek();
}

int StringSound::time(){
	return ticsPassed;
}

//made to facilitate making of frequency chirp
int StringSound::getBufferSize(){
	return buffer->size();
}

StringSound::~StringSound(){
	//delete buffer;
}

