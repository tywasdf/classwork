/*
Troy Wang
Comp 2040
PS3a
*/

#ifndef CIRCLEBUFFER_H
#define CIRCLEBUFFER_H

#include <stdint.h>
#include <vector>

class CircleBuffer{
  public:
    // required constructor listed in pdf
    CircleBuffer(int capacity);
    
    // required functions listed in pdf
    int size();
    int capacity();
    bool isEmpty();
    bool isFull();
    void enqueue(int16_t x);
    int16_t dequeue();
    int16_t peek();
    void empty();

  private:
  // private member variables 
  int bufferTail;
  int bufferHead;
  int bufferCapacity;
  int bufferSize;
  // using vector to hold the ring buffer
  std::vector<int16_t> buffer;
};

#endif //CIRCLEBUFFER_H
