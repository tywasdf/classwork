/**********************************************************************
 *                                                  
 *  PS3b: StringSound implementation and SFML audio output 
 **********************************************************************/

Name: Troy Wang

Hours to complete assignment : 4 hours

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/
I did complete the whole assignment. I was able to make the StringSound class and the KSGuitarSim file.
Together, I am able to use the keyboards to produce a sound through sfml.


/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  As a pair, or individually?
 **********************************************************************/


/**********************************************************************
 *  Did you implement exseptions to check your StringSound 
 *	implementation?
 *  Indicate yes or no, and explain how you did it.
 **********************************************************************/
I did include a couple exceptions into my StringSound implementation. The constructor checks to make sure the frequency is within a certain range that will produce the right capacity for the CircleBuffer private member. If it is not, it will throw an invalid argument error.

I also throw an exception for the StringSound sample function if the buffer is empty. 
/**********************************************************************
 *  List whatever help (if any) you received from TAs,
 *  classmates, or anyone else.
 **********************************************************************/

None

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
I tried to use a smart pointer in the StringSound class so that I would not have to define a destructor, but I found that for some reason the destructor seemed to be called very quickly after the constructor, so I had to just revert back to the raw pointer.

I also tried to make a destructor where i called delete on the raw pointer, however, I noticed that I would segfault at close because of it. Because of that, I have removed it.
/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
This second submission is because I forgot to use a lambda expression and to fix the segfault on close.

I use the lambda expression in my StringSound constructor definition when I am making the private CircleBuffer.
