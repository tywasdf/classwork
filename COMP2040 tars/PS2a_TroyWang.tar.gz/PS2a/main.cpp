/*
Troy Wang
Comp 2040
PS2a
*/

#include "Universe.hpp"
#include <SFML/Graphics.hpp>

int main(){
  int numPlanets;
  float radius;
  std::cin >> numPlanets >> radius;
  
  
  universe galaxy = universe(numPlanets, radius);
  
  sf::RenderWindow window(sf::VideoMode(defaultWindowSize.x, defaultWindowSize.y), "The Galaxy");
  
  //create image for background
  sf::Image background;
  
  //if load fails, throw error
  if(!background.loadFromFile("space.png")){
     throw std::invalid_argument("no file for celestialImage");
  }
  
  //creating texture for background
  sf::Texture backgroundTexture;
  backgroundTexture.loadFromImage(background);
  
  //creating sprite for background
  sf::Sprite backgroundSprite;
  backgroundSprite.setTexture(backgroundTexture);
  
  while (window.isOpen()){
        // Process events
        sf::Event event;
        while (window.pollEvent(event)){
            // Close window: exit
            if (event.type == sf::Event::Closed){
                window.close();
            }
        }
        window.clear();
        
        //draw background
        window.draw(backgroundSprite);
        
  
        //function in universe class to draw all celestialBodies in universe object uses target.draw() in the function.
        galaxy.draw(window);
        
        window.display();
    }
    
    
  return 0;
}