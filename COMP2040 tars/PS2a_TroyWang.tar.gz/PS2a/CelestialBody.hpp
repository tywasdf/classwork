/*
Troy Wang
Comp 2040
PS2a
*/


#ifndef  CELESTIALBODY_H
#define  CELESTIALBODY_H

#include <iostream>
#include <string>
#include <vector>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>


// Constants for the window size.
const sf::Vector2u defaultWindowSize(1000, 1000);

class celestialBody: public sf::Drawable{
public:
  

  // Constructors
  celestialBody();
  
  celestialBody(double posX, double posY, double velX, double velY, double mass, std::string file);

  
  void set_position(float radius, sf::Vector2u windowSize = defaultWindowSize); // Sets the planets positions will default to 1000x1000 screen size

  // Overridden operator >> for inputing from a file
  friend std::istream& operator>> (std::istream &input, celestialBody &body);

  // Overriddden operator << for debugging
  friend std::ostream& operator<< (std::ostream &output, celestialBody &body);
  
  

private:

  // Draw method
  void virtual draw(sf::RenderTarget& target, sf::RenderStates states) const;

  // Member variables
  double positionX, positionY, velocityX, velocityY, celestialMass;
  std::string fileName;

  // Image related objects
  sf::Image celestialImage;
  sf::Sprite celestialSprite;
  sf::Texture celestialTexture;
};

#endif //CELESTIALBODY_H