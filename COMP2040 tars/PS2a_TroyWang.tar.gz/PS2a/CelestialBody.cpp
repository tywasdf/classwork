/*
Troy Wang
Comp 2040
PS2a
*/

#include "CelestialBody.hpp"

//default constructor doesn't need to do anything, since the >> operator will set everything
celestialBody::celestialBody(){
  return;
}
 
 //sets values if given
celestialBody::celestialBody(double posX, double posY, double velX, double velY, double mass,  std::string file){
  positionX = posX;
  positionY = posY;
  velocityX = velX;
  velocityY = velY;
  celestialMass = mass;
  fileName = file;
  
  if(celestialImage.loadFromFile(fileName)){
    return;
  }
  
  celestialTexture.loadFromImage(celestialImage);
  celestialSprite.setTexture(celestialTexture);
}


void celestialBody::set_position(float radius, sf::Vector2u windowSize){              // Sets the planets positions based on window size, will default to 1000,1000.
 
/*
  The math for this is obtain a ratio for the size of the screen. then multiplies it by distance from center of universe(which is half of the screen) to figure out where in relation to the center the celestialBody is. Then offsets both x and y based of coordinates of center of the universe.
*/
  positionX = ( (positionX / radius) * ( windowSize.x / 2) ) + ( windowSize.x / 2);
  positionY = ( (positionY / radius) * ( windowSize.y / 2) ) + ( windowSize.y / 2);
  
  //apply position to sprite.
  celestialSprite.setPosition(positionX, positionY);
}

// Overridden operator >> for inputing from a file
std::istream& operator>> (std::istream &input, celestialBody &body){
  //read in all the information
  input >> body.positionX >> body.positionY >> body.velocityX >> body.velocityY >> body.celestialMass >> body.fileName;
  
  //set the images and positions, like the parameter constructor.
   if(!body.celestialImage.loadFromFile(body.fileName)){
    throw std::invalid_argument("no file for celestialImage");
  }
  
  body.celestialTexture.loadFromImage(body.celestialImage);
  body.celestialSprite.setTexture(body.celestialTexture);

  return input;
}

//overridden operator << for testing purposes.
std::ostream& operator<< (std::ostream &output, celestialBody &body)
{
  // For debugging, output all the data stored in the object.
  output << "File name: " << body.fileName << std::endl << "X position: " << body.positionX << std::endl << "Y position: " << body.positionY << std::endl << "X velocity: " << body.velocityX << std::endl << "Y velocity: " << body.velocityY << std::endl << "Mass: " << body.celestialMass << std::endl;

  return output;
}

// Drawable method
void celestialBody::draw(sf::RenderTarget& target, sf::RenderStates states) const
{
  // draw the image
  target.draw(celestialSprite);
}

