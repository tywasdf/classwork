/**********************************************************************
 *  N-Body Simulation ps2a-readme.txt template
 **********************************************************************/

Name: Troy Wang
Hours to complete assignment: 5 hours

/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
This program displays the planets in a sfml window. It gets the information from the planets.txt text file (when input is redirected to planets.txt) and creates celestialBody objects.
In order to collect the information, the >> operator was overloaded to facilitate the creation of the celestialBody objects.

I also created a universe class to hold the celestialBody objects and used that class to also facilitate the drawing of the whole collection. 


  /**********************************************************************
 *  Discuss one or more key algorithms, data structures, or 
 *  OO designs that were central to the assignment.
 **********************************************************************/

The calculations for finding out the positions of the celestialBodies was done by making a ratio of the distance from the center of a celestialBody and the radius of the universe. 
Then, that was multiplied by the radius of the universe to get the distance on the screen of how far the celestialBody was from the center. Finally, I applied the offset so that it was actually
being placed in relation to the center. This was done for both the x and y coordinates. I also made it so that we could pass the window size through the set_position function so that if we wanted to increase the window size
we could draw it regardless of the default window size. (we would still have to prompt them if they wanted a new window size though! Or I could add an event on window resize to check.)

I also used a vector in the universe class to hold the celestialBodies. This made managing the celestialBodies very intuitive.



/**********************************************************************
 *  Briefly explain the workings of the features you implemented.
 *  Describe if and how do you used the smart pointers 
 *  Include code excerpts.
 **********************************************************************/
In order to collect the information, the >> operator was overloaded to facilitate the creation of the celestialBody objects.

Here is the line of code i us to take in the code and assign it to the private variables:
input >> body.positionX >> body.positionY >> body.velocityX >> body.velocityY >> body.celestialMass >> body.fileName; 

The calculations for finding out the positions of the celestialBodies that was mentioned above was done through 2 lines of code listed below:
positionX = ( (positionX / radius) * ( windowSize.x / 2) ) + ( windowSize.x / 2);
positionY = ( (positionY / radius) * ( windowSize.y / 2) ) + ( windowSize.y / 2);

I did use smart pointers. I used them in the universe class inside my vector. The vector is actually a vector of shared_ptr that point to the celestialBodies.
Here is the code where I declare it as a private variable in the Universe.hpp(under the private section, which is not pasted below):

std::vector<std::shared_ptr<celestialBody>> celestialBodies;



/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
None

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
I struggled a bit with the make file this time as I initially tried to have too many overlapping dependencies since I had never compiled 3 cpp files together before. 
Then, my editor seemed to randomly shift and started switching my tabs to spaces, which caused a different issue with the makefile. Obviously, this all got sorted out as the
makefile functions as intended.

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

I did load a background image for the extra credit!.

Once again, I named this ps3a-readme to match what it says at the end of the pdf, but I realize this is for ps2a.