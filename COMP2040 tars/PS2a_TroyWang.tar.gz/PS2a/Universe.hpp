/*
Troy Wang
Comp 2040
PS2a
*/

#ifndef  UNIVERSE_H
#define  UNIVERSE_H

#include "CelestialBody.hpp"
#include <vector>
#include <memory>

class universe{
  public:
    //default constructor
    universe();            
    
    //parameter constructor              
    universe(float radius);
    
    //constructor for taking in input from txt doc.
    universe(int numOfCelestialBodies, float radius);
    
    //set radius if needed
    void set_radius(float radius);
    
    //calculate positions based on window size.
    void set_position(sf::Vector2u windowSize = defaultWindowSize);
  
    // Draw method for universe
    void virtual draw(sf::RenderTarget& target) const;
  
    //for testing 
    void print ();
  
  private:
  double universeRadius;
  
  //using a vector of shared_ptr to hold celestialBodies
  std::vector<std::shared_ptr<celestialBody>> celestialBodies;
};


#endif //UNIVERSE_H