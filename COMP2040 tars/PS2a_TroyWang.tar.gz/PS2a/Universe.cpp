/*
Troy Wang
Comp 2040
PS2a
*/

#include "Universe.hpp"

universe::universe(){
  return;
}

universe::universe(float radius){
  universeRadius = radius;
}

//constructor for taking in input from txt doc.
universe::universe(int numOfCelestialBodies, float radius){

  //for loop to collect data for the number of celestial bodies.
  for(int i=0; i<numOfCelestialBodies; i++){
    std::shared_ptr<celestialBody> temp = std::make_shared<celestialBody> ();
    std::cin >> *temp;
  
    //calculate initial position for all bodies as we loop through
    temp->set_position(radius);
    
    //add the body to the vector
    celestialBodies.push_back(temp);
  
    //used for testing
    //std::cout << *temp;
  }
}

//sets the radius if we need to.
void universe::set_radius(float radius){
  universeRadius = radius;
  return;
}

//uses an iterator to go through and set position of each celestialBody
void universe::set_position(sf::Vector2u windowSize){
  for(auto it = celestialBodies.begin(); it != celestialBodies.end(); ++it){
    (**it).set_position(universeRadius, windowSize);
  }
}


//uses an iterator to go through and draw each celestialBody
void universe::draw(sf::RenderTarget& target) const{
  for(auto it = celestialBodies.begin(); it != celestialBodies.end(); ++it){
    target.draw(**it);
  }
}

//print function for testing.
void universe::print (){
  for(auto it = celestialBodies.begin(); it != celestialBodies.end(); ++it){
    std::cout << **it;
  }
}

