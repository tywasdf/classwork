// Dr. Rykalova
// test.cpp for PS1a
// updated 1/31/2020

#include <iostream>
#include <string>

#include "FibLFSR.h"

#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE Main
#include <boost/test/included/unit_test.hpp>

//initial test in file.
BOOST_AUTO_TEST_CASE(sixteenBitsThreeTaps) {

  FibLFSR l("1011011000110110");
  BOOST_REQUIRE(l.step() == 0);
  BOOST_REQUIRE(l.step() == 0);
  BOOST_REQUIRE(l.step() == 0);
  BOOST_REQUIRE(l.step() == 1);
  BOOST_REQUIRE(l.step() == 1);
  BOOST_REQUIRE(l.step() == 0);
  BOOST_REQUIRE(l.step() == 0);
  BOOST_REQUIRE(l.step() == 1);

  FibLFSR l2("1011011000110110");
  BOOST_REQUIRE(l2.generate(9) == 51);
}

BOOST_AUTO_TEST_CASE(constructors){
  FibLFSR normalConstructorTest("1011011000110110"); //makes a constructor with 16 bits, which should work
  
  boost::test_tools::output_test_stream output; //redirects the constructors overloaded << to the boost test stream.
  output << normalConstructorTest; 
  BOOST_REQUIRE(output.is_equal("1011011000110110")); //checks to see if output matches what it is supposed to be, which is the parameter for the constructor
  
  BOOST_CHECK_THROW(FibLFSR normalConstructorTest("10110110001"), std::length_error); //makes a constructor with 11 bits, which should throw an exception due to length
  
  BOOST_CHECK_THROW(FibLFSR normalConstructorTest("10110110001000000"), std::length_error); //makes a constructor with 17 bits, which should throw an exception due to length
  
  BOOST_CHECK_THROW(FibLFSR normalConstructorTest("101101100011011A"), std::invalid_argument); //makes a constructor with 11 bits, which should throw an exception due to invalid argument (bits aren't 0's and 1's)
}

//more extensive generate tests
BOOST_AUTO_TEST_CASE(moreGenerate) {

  FibLFSR generatorTest("1010101111000111");
  
  //just checks generate function at different k values. 
  BOOST_REQUIRE(generatorTest.generate(5) == 4);
  BOOST_REQUIRE(generatorTest.generate(7) == 32);
  BOOST_REQUIRE(generatorTest.generate(11) == 893);
  BOOST_REQUIRE(generatorTest.generate(13) == 3929);
  BOOST_REQUIRE(generatorTest.generate(4) == 8);
  BOOST_REQUIRE(generatorTest.generate(15) == 7711);
  BOOST_REQUIRE(generatorTest.generate(16) == 21874);
  BOOST_CHECK_THROW(generatorTest.generate(20), std::invalid_argument); // should throw an invalid argument exception because k is larger than the 16 bit register.
  BOOST_CHECK_THROW(generatorTest.generate(-5), std::invalid_argument); // should throw an invalid argument exception because k is negative


}