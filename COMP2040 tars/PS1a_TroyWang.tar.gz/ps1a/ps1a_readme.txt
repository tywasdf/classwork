/**********************************************************************
 *  Linear Feedback Shift Register (part A) ps1a-readme.txt template
 **********************************************************************/

Name: Troy Wang
Hours to complete assignment:3
/**********************************************************************
 *  Briefly discuss the assignment itself and what you accomplished.
 **********************************************************************/
I created a 16 bit register using strings. The register had 3 hardcoded taps (at 13,12,and 10). 
Strings were a easy way to implement it because chars all extend from a known value for numbers subtracting by '0' will get you the numerical value of any number char, and indexes are easy to obtain. I will note that if we want a tap on the 13th but, that would be the 2nd index because index 0 is the most significant bit instead of the least significant, which is what it would be if we were looking at it on paper.

The program can step and produce a single "random" bit, or can have multiple steps be simulated using the generate function, which creates a top for higher possible numbers to be obtained.

The current register can also be printed out using the << function.

I used string methods to modify the register as I progressed through with steps and generate, using the substringmethod to cut the most significant bit and then string addition to add on the the new bit.


/**********************************************************************
 *  If you did any implementation for extra credit, describe it
 *  here and why it is interesting.
 **********************************************************************/
None


/**********************************************************************
 *  List whatever help (if any) you received from the instructor,
 *  classmates, or anyone else.
 **********************************************************************/
None

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
I had some trouble with the boost library, as I had to modify the include statement for it. I also didn't really understand a whole lot about connecting the FibLFSR.cpp file to the test.o file, so I was having trouble with compiling it and having the test file understand what the functions were supposed to be doing. However, I obviously figured it out, so no large issues that still confuse me.

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
 
 My first test checks the constructors. I made sure to include seeds that have alphanumeric characters, as well as bits that were too long or too short.
 
 My second test was a more intensive test of the generate function (and, indirectly, the step function). I checked a whole bunch of different values for the k value(the number of steps) and even checked the exceptions that I throw for when the value is a negative or greater than the number of bits in the register.